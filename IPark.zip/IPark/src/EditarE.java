
import DAO.EditarDAO;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelos.ClientesE;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author julia
 */
public class EditarE extends javax.swing.JFrame {

    /**
     * Creates new form EditarE
     */
    public EditarE() {
        initComponents();
    }
    
      public void preenche1(){
        String cn = "SELECT NomeE FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(cn);
        try{
            while(retorno.next()){
                jTextField1.setText(retorno.getString("NomeE"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        }
        }
        
        public void preenche2(){
        String ce = "SELECT EmailE FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(ce);
        try{
            while(retorno.next()){
                jTextField2.setText(retorno.getString("EmailE"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        }
        }
        
        public void preenche3(){
        String ct = "SELECT Telefone FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(ct);
        try{
            while(retorno.next()){
                jTextField3.setText(retorno.getString("Telefone"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        } 
        }
        
        public void preenche10(){
        String ct = "SELECT Qtd FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(ct);
        try{
            while(retorno.next()){
                jTextField11.setText(retorno.getString("Qtd"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        } 
        }
        
        public void preenche4(){
        String cc1 = "SELECT Carro1 FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(cc1);
        try{
            while(retorno.next()){
                jTextField4.setText(retorno.getString("Carro1"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        } 
        }
        
        public void preenche5(){
        String cc2 = "SELECT Carro2 FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(cc2);
        try{
            while(retorno.next()){
                jTextField5.setText(retorno.getString("Carro2"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        } 
        }
        
        public void preenche6(){
        String ct = "SELECT Carro3 FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(ct);
        try{
            while(retorno.next()){
                jTextField6.setText(retorno.getString("Carro3"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        } 
        }
        
        public void preenche7(){
        String cc1 = "SELECT Carro4 FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(cc1);
        try{
            while(retorno.next()){
                jTextField8.setText(retorno.getString("Carro4"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        } 
        }
        
        public void preenche8(){
        String cc2 = "SELECT Carro5 FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(cc2);
        try{
            while(retorno.next()){
                jTextField9.setText(retorno.getString("Carro5"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        } 
        }
        
        public void preenche9(){
        String ct = "SELECT Carro6 FROM ClienteE WHERE idClienteE =" + jTextField7.getText();
        ResultSet retorno;
        EditarDAO DAO = new EditarDAO();
        retorno = DAO.consulta(ct);
        try{
            while(retorno.next()){
                jTextField10.setText(retorno.getString("Carro6"));
            }
        }
        catch(Exception ex){
            ex.printStackTrace(System.out);
        } 
        }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField7 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();
        jRadioButton7 = new javax.swing.JRadioButton();
        jRadioButton8 = new javax.swing.JRadioButton();
        jRadioButton9 = new javax.swing.JRadioButton();
        jTextField11 = new javax.swing.JTextField();
        jRadioButton10 = new javax.swing.JRadioButton();

        jPanel1.setBackground(new java.awt.Color(146, 211, 110));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/iconfinder_construction-industry-building-50_4137143.png"))); // NOI18N
        jLabel1.setText("ID Empresa:");

        jTextField1.setText("Nome");
        jTextField1.setToolTipText("Nome");

        jTextField2.setText("Email");

        jTextField3.setText("Telefone");

        jRadioButton1.setText("Alterar");

        jRadioButton2.setText("Alterar");

        jRadioButton3.setText("Alterar");

        jButton1.setText("Atualizar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Excluir Empresa");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Pesquisar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(98, 156, 68));

        jLabel4.setText("Carro 1");

        jLabel5.setText("Carro 2");

        jLabel6.setText("Carro 3");

        jLabel9.setText("Carro 5");

        jLabel10.setText("Carro 6");

        jLabel8.setText("Carro 4");

        jRadioButton4.setText("Alterar");

        jRadioButton5.setText("Alterar");

        jRadioButton6.setText("Alterar");

        jRadioButton7.setText("Alterar");

        jRadioButton8.setText("Alterar");

        jRadioButton9.setText("Alterar");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jRadioButton4)
                                .addGap(0, 94, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField10)
                                    .addComponent(jTextField8, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jTextField5)
                                    .addComponent(jTextField4)
                                    .addComponent(jTextField9)
                                    .addComponent(jTextField6))))
                        .addContainerGap())
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jRadioButton9)
                            .addComponent(jRadioButton8)
                            .addComponent(jRadioButton7)
                            .addComponent(jRadioButton6)
                            .addComponent(jRadioButton5))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jRadioButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton6)
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton7)
                .addGap(13, 13, 13)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addComponent(jRadioButton8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton9)
                .addGap(20, 20, 20))
        );

        jTextField11.setText("Qtd");
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });

        jRadioButton10.setText("Alterar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton3))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(106, 106, 106)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jRadioButton1)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jRadioButton2)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jRadioButton3)
                                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jRadioButton10))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(128, 128, 128))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(79, 79, 79)))
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(15, 15, 15))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        ClientesE cliente = new ClientesE();
        Connection con = new ConnectionFactory().conecta();
        if (jRadioButton1.isSelected()) {
            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET NomeE = '" + jTextField1.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
                
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);
            }
            if(jTextField1.getText() == null){
                JOptionPane.showMessageDialog(null, "Preenchemento Obrigatório");
            }
            cliente.setNome(jTextField1.getText());
        }

        
        if (jRadioButton2.isSelected()) {

            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET EmailE = '" + jTextField2.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
               
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);
            }
            if(jTextField2.getText() == null){
                JOptionPane.showMessageDialog(null, "Preenchemento Obrigatório");
            }
            cliente.setEmail(jTextField2.getText());
        }
        if (jRadioButton3.isSelected()) {
            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET Telefone = '" + jTextField3.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
               
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);
            }
            if(jTextField3.getText() == null){
                JOptionPane.showMessageDialog(null, "Preenchemento Obrigatório");
            }
            cliente.setTelefone(jTextField3.getText());
        }
         if (jRadioButton10.isSelected()) {
            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET Qtd = '" + jTextField11.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
                
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);
            }
            if(jTextField11.getText() == null){
                JOptionPane.showMessageDialog(null, "Preenchemento Obrigatório");
            }
            cliente.setQtd(Integer.parseInt(jTextField11.getText()));
        }
       if (jRadioButton4.isSelected()) {

            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET Carro1 = '" + jTextField4.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
               
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);;
            }
            if(jTextField4.getText() == null){
                JOptionPane.showMessageDialog(null, "Preenchemento Obrigatório");
            }
            cliente.setCarro1(jTextField4.getText());
        }
       if (jRadioButton5.isSelected()) {

            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET Carro2 = '" + jTextField5.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
                
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);
            }
            cliente.setCarro2(jTextField5.getText());
        }
       if (jRadioButton6.isSelected()) {

            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET Carro3 = '" + jTextField6.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
                
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);
            }
            cliente.setCarro3(jTextField6.getText());
        }
        if (jRadioButton7.isSelected()) {

            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET Carro4 = '" + jTextField8.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
                
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);;
            }
            cliente.setCarro4(jTextField8.getText());
        }
        if (jRadioButton8.isSelected()) {

            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET Carro5 = '" + jTextField9.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
                
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);
            }
            cliente.setCarro5(jTextField5.getText());
        }
        if (jRadioButton9.isSelected()) {

            try{
                PreparedStatement stmt = con.prepareStatement("UPDATE ClienteE SET Carro6 = '" + jTextField10.getText() + "' WHERE idClienteE = " + jTextField7.getText());
                stmt.executeUpdate();
                stmt.close();
                
            }
            catch(Exception erro){
                System.err.println("Erro UPDATE:" + erro);
            }
            cliente.setCarro6(jTextField10.getText());
            
        }
        JOptionPane.showMessageDialog(null,"Dados Gravados com Sucesso","Atenção", JOptionPane.INFORMATION_MESSAGE);
        cliente.salvar();
        jTextField1.setText("Nome");
        jTextField2.setText("Email");
        jTextField3.setText("Telefone");
        jTextField11.setText("Qtd");
        jTextField4.setText("Carro 1");
        jTextField5.setText("Carro 2");
        jTextField6.setText("Carro 3");
        jTextField8.setText("Carro 4");
        jTextField9.setText("Carro 5");
        jTextField10.setText("Carro 6");
        jRadioButton1.setSelected(false);
        jRadioButton2.setSelected(false);
        jRadioButton3.setSelected(false);
        jRadioButton4.setSelected(false);
        jRadioButton5.setSelected(false);
        jRadioButton6.setSelected(false);
        jRadioButton7.setSelected(false);
        jRadioButton8.setSelected(false);
        jRadioButton9.setSelected(false);
        jRadioButton10.setSelected(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Connection con = new ConnectionFactory().conecta();
        try{
            PreparedStatement stmt = con.prepareStatement("DELETE FROM ClienteE WHERE idClienteE = "+ jTextField7.getText());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null,"Dados Deletados com Sucesso","Atenção", JOptionPane.INFORMATION_MESSAGE);
        }
        catch(Exception erro){
            JOptionPane.showMessageDialog(null,"Ocorreu um erro","Atenção", JOptionPane.INFORMATION_MESSAGE);
            System.err.println("Erro DELETE:" + erro);
        }
        jTextField1.setText("Nome");
        jTextField2.setText("Email");
        jTextField3.setText("Telefone");
        jTextField11.setText("Qtd");
        jTextField4.setText("Carro 1");
        jTextField5.setText("Carro 2");
        jTextField6.setText("Carro 3");
        jTextField8.setText("Carro 4");
        jTextField9.setText("Carro 5");
        jTextField10.setText("Carro 6");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        preenche1();
        preenche2();
        preenche3();
        preenche4();
        preenche5();
        preenche6();
        preenche7();
        preenche8();
        preenche9();
        preenche10();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditarE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditarE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditarE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditarE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditarE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton10;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    private javax.swing.JRadioButton jRadioButton7;
    private javax.swing.JRadioButton jRadioButton8;
    private javax.swing.JRadioButton jRadioButton9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
