package modelos;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Clientes {
    private int id;
    private String pagto;
    private String nome;
    private String carro1;
    private String carro2;
    private String carro3;
    private String email;
    private String telefone;
    
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
    public String getPagto(){
        return pagto;
    }
    public void setPagto(String pagto){
        this.pagto = pagto;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCarro1() {
        return carro1;
    }

    public void setCarro1(String carro1) {
        this.carro1 = carro1;
    }
    public String getCarro2() {
        return carro2;
    }

    public void setCarro2(String carro2) {
        this.carro2 = carro2;
    }
    public String getCarro3() {
        return carro3;
    }

    public void setCarro3(String carro3) {
        this.carro3 = carro3;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public String salvar(){
      
        try {
            Clientes cliente = new Clientes();
            FileWriter fw = new FileWriter("clientes.txt");
            fw.write("Nome: " + getNome() + "\n");
            fw.write("Email: " + getEmail() + "\n");
            fw.write("Telefone: " + getTelefone() + "\n");
            fw.write("Carro 1: " + getCarro1() + "\n");
            fw.write("Carro 2: " + getCarro2() + "\n");
            fw.write("Carro 3: " + getCarro3() + "\n");
            fw.write("Pagto: " + getPagto() + "\n");
            fw.flush();
            fw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "Cadastrado com Sucesso!";
    }
}
