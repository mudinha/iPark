package modelos;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ClientesE {
    private int id;
    private int qtd;
    private String pagto;
    private String nome;
    private String carro1;
    private String carro2;
    private String carro3;
    private String carro4;
    private String carro5;
    private String carro6;
    private String email;
    private String telefone;
    
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
    public String getPagto(){
        return pagto;
    }
    public void setPagto(String pagto){
        this.pagto = pagto;
    }
    
    public int getQtd(){
        return qtd;
    }
    public void setQtd(int qtd){
        this.qtd = qtd;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCarro1() {
        return carro1;
    }

    public void setCarro1(String carro1) {
        this.carro1 = carro1;
    }
    public String getCarro2() {
        return carro2;
    }

    public void setCarro2(String carro2) {
        this.carro2 = carro2;
    }
    public String getCarro3() {
        return carro3;
    }
    
    
    public void setCarro3(String carro3) {
        this.carro3 = carro3;
    }
    
    public String getCarro4() {
        return carro4;
    }
    
    public void setCarro4(String carro4) {
        this.carro4 = carro4;
    }
    public String getCarro5() {
        return carro5;
    }

    public void setCarro5(String carro5) {
        this.carro5 = carro5;
    }
    public String getCarro6() {
        return carro6;
    }

    public void setCarro6(String carro6) {
        this.carro6 = carro6;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public String salvar(){
      
        try {
            ClientesE cliente = new ClientesE();
            FileWriter fw = new FileWriter("clientesE.txt");
            fw.write("Nome: " + getNome() + "\n");
            fw.write("Email: " + getEmail() + "\n");
            fw.write("Telefone: " + getTelefone() + "\n");
            fw.write("Qtd: " + getQtd() + "\n");
            fw.write("Carro 1: " + getCarro1() + "\n");
            fw.write("Carro 2: " + getCarro2() + "\n");
            fw.write("Carro 3: " + getCarro3() + "\n");
            fw.write("Carro 4: " + getCarro4() + "\n");
            fw.write("Carro 5: " + getCarro5() + "\n");
            fw.write("Carro 6: " + getCarro6() + "\n");
            fw.write("Pagto: " + getPagto() + "\n");
            fw.flush();
            fw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "Cadastrado com Sucesso!";
    }
}
