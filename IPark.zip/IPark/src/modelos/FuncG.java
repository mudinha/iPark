/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author julia
 */
public class FuncG {
     private int id;
    private String nome;
    private String email;
    private String usuario;
    private String senha;
    private String arquivo;
    private String telefone;
    

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }
    
    public String getSenha(){
        return senha;
    }
    public void setSenha(String senha){
        this.senha = senha;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    public String salvar(){
        
        try {
            FileWriter fw = new FileWriter("gerentes.txt");
            fw.write("Nome: "+ getNome() + "\n");
            fw.write("Email: "+ getEmail() + "\n");
            fw.write("Telefone: "+ getTelefone() + "\n");
            fw.write("Usuario: "+ getUsuario() + "\n");
            fw.write("Arquivo: " + getArquivo() + "\n");
            fw.close();
            fw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        return null;
    }
}
