/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author julia
 */
public class ClientesA {
    private int id;
    public String entrada;
    public String saida;
    public String carro;
    public String pagto;
    
     public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
    public String getEnt(){
        return entrada;
    }
    public void setEnt(String entrada){
        this.entrada = entrada;
    }
    public String getSai(){
        return saida;
    }
    public void setSai(String saida){
        this.saida = saida;
    }
    public String getCarro(){
        return carro;
    }
    public void setCarro(String carro){
        this.carro = carro;
    }
    public String getPag(){
        return pagto;
    }
    public void setPag(String pagto){
        this.pagto = pagto;
    }
    
     public String salvar(){
      
        try {
            ClientesA cliente = new ClientesA();
            FileWriter fw = new FileWriter("clientesA.txt");
            fw.write("Id: " + getId() + "\n");
            fw.write("Entrada: " + getEnt() + "\n");
            fw.write("Saida: " + getSai() + "\n");
            fw.write("Carro: " + getCarro() + "\n");
            fw.write("Pagto: " + getPag() + "\n");
            fw.flush();
            fw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "Cadastrado com Sucesso!";
    }
    
}
