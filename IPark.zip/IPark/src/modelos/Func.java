package modelos;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Func {
    private int id;
    private String nome;
    private String email;
    private String telefone;
    private String senha;
    private String gerente;
    private String arq;

    public String getArq(){
        return arq;
    }

    public void setArq(String arquivo) {
        this.arq = arquivo;
    }
    
    public String getGerente(){
        return gerente;
    }
    public void setGerente(String gerente){
        this.gerente = gerente;
    }
    
    public String getSenha(){
        return senha;
    }
    public void setSenha(String senha){
        this.senha = senha;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    public String salvar(){
      
        try {
            FileWriter fw = new FileWriter("funcionarios.txt");
            fw.write("Nome: "+ getNome() + "\n");
            fw.write("Email: "+ getEmail() + "\n");
            fw.write("Telefone: "+ getTelefone() + "\n");
            fw.write("Gerente: "+ getGerente() + "\n");
            fw.write("Arquivo: " + getArq() + "\n");
            fw.close();
            fw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        return null;
    }
}
