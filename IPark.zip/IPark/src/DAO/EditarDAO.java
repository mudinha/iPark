package DAO;

import factory.ConnectionFactory;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EditarDAO {
    
    public ResultSet consulta(String local){
        ResultSet rs = null;
        Connection connection = new ConnectionFactory().conecta();
        try{
           PreparedStatement stmt = connection.prepareStatement(local);
           rs = stmt.executeQuery();
        }
        catch(Exception e){
            System.err.println("Erro CONSULTA:" + e);
        }
        return rs;
    }
}
