package DAO;
import factory.ConnectionFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import modelos.Func;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class FuncDAO { 
    Long id;
    String nome;
    String email;
    String telefone;
    public void adiciona(Func func){
            Connection con = new ConnectionFactory().conecta();
                try { 
                    /*PreparedStatement stmt = con.prepareStatement("INSERT INTO Func (NomeF,EmailF,TelefoneF,SenhaF,Gerente,Foto) VALUES('"
                            + func.getNome() + "','" + func.getEmail() + "','" + func.getTelefone() + "','" + func.getSenha() + "','" + func.getGerente() + "',?);");*/
                    String sql = "INSERT INTO Func (NomeF,EmailF,TelefoneF,SenhaF,Gerente,Foto) VALUES (?,?,?,?,?,?)";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setString(1,func.getNome());                 
                    stmt.setString(2,func.getEmail());
                    stmt.setString(3,func.getTelefone());
                    stmt.setString(4,func.getSenha());                 
                    stmt.setString(5,func.getGerente());
                    
                    File arq = new File(func.getArq());
                    FileInputStream inputStream = null;
                        try {
                            inputStream = new FileInputStream(arq);
                        } catch (FileNotFoundException ex) {
                            System.err.println("Erro - " + ex);
                        }
            
                        stmt.setBinaryStream(6,inputStream, (int) arq.length());
                        stmt.execute();
                        stmt.close();
                } catch (SQLException ex) { 
                    System.err.println("Erro INSERT:" + ex);
                }
            }
    
    
    public ResultSet seleciona(String local){
        ResultSet rs = null;
            Connection connection = new ConnectionFactory().conecta();
            try {
              PreparedStatement stmt = connection.prepareStatement(local);
              rs = stmt.executeQuery();
            }
            catch (SQLException ex)
            {
                System.err.println("Erro CONSULTA:" + ex);
            }
            return rs;
    }
    
    public List<Func> read() {
        Connection con = new ConnectionFactory().conecta();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Func> funcios = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM Func");
            rs = stmt.executeQuery();
            
            while (rs.next()){
                Func funcio = new Func();
                funcio.setId(rs.getInt("idFunc"));
                funcio.setNome(rs.getString("NomeF"));
                funcio.setEmail(rs.getString("EmailF"));
                funcio.setTelefone(rs.getString("TelefoneF"));
                funcio.setGerente(rs.getString("Gerente"));
                funcios.add(funcio);
                
            }
            
        } catch (SQLException ex) {
            System.out.println("Lista não concluída");;
        }finally{
           ConnectionFactory.fechaConexao(con, (com.mysql.jdbc.PreparedStatement) stmt, rs);
        }
        return funcios;
        }
    
     public List<Func> readForNome(String nome) {
        Connection con = new ConnectionFactory().conecta();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Func> funcios = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM Func WHERE NomeF LIKE ?");
            stmt.setString(1, "%"+nome+"%");
            
            rs = stmt.executeQuery();
            
            while (rs.next()){
                Func funcio = new Func();
                funcio.setId(rs.getInt("idFunc"));
                funcio.setNome(rs.getString("NomeF"));
                funcio.setEmail(rs.getString("EmailF"));
                funcio.setTelefone(rs.getString("TelefoneF"));
                funcio.setGerente(rs.getString("Gerente"));
                funcios.add(funcio);
                
            }
            
        } catch (SQLException ex) {
            System.out.println("Lista não concluída");;
        }finally{
           ConnectionFactory.fechaConexao(con, (com.mysql.jdbc.PreparedStatement) stmt, rs);
        }
        return funcios;
        }
    }
