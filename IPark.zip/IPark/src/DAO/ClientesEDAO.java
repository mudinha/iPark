/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.ClientesE;

/**
 *
 * @author julia
 */
public class ClientesEDAO {
    Long id;
    String entrada;
    String saida;
    String carro;
    
    public void adiciona(ClientesE cliente){
      String neg = "NÃO";
        Connection con = new ConnectionFactory().conecta();
        try { 
            String sql = "INSERT INTO ClienteE (NomeE,EmailE,Telefone,Qtd,Carro1,Carro2,Carro3,Carro4,Carro5,Carro6,Pagto) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setString(1,cliente.getNome());                 
                    stmt.setString(2,cliente.getEmail());
                    stmt.setString(3,cliente.getTelefone());
                    stmt.setInt(4,cliente.getQtd());
                    stmt.setString(5,cliente.getCarro1());                 
                    stmt.setString(6,cliente.getCarro2());
                    stmt.setString(7,cliente.getCarro3());
                    stmt.setString(8,cliente.getCarro4());                 
                    stmt.setString(9,cliente.getCarro5());
                    stmt.setString(10,cliente.getCarro6());
                    stmt.setString(11,neg);
                    
                    stmt.execute();
                    stmt.close();
        } 
        catch (SQLException ex) { 
            System.err.println("Erro INSERT:" + ex);
        }
    }
    
     public List<ClientesE> read() {
        Connection con = new ConnectionFactory().conecta();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<ClientesE> clientes = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM ClienteE");
            rs = stmt.executeQuery();
            
            while (rs.next()){
                ClientesE cliente = new ClientesE();
                cliente.setId(rs.getInt("idClienteE"));
                cliente.setNome(rs.getString("NomeE"));
                cliente.setEmail(rs.getString("EmailE"));
                cliente.setTelefone(rs.getString("Telefone"));
                cliente.setCarro1(rs.getString("Carro1"));
                cliente.setCarro2(rs.getString("Carro2"));
                cliente.setCarro3(rs.getString("Carro3"));
                cliente.setCarro4(rs.getString("Carro4"));
                cliente.setCarro5(rs.getString("Carro5"));
                cliente.setCarro6(rs.getString("Carro6"));
                cliente.setPagto(rs.getString("Pagto"));
                clientes.add(cliente);
                
            }
            
        } catch (SQLException ex) {
            System.out.println("Lista não concluída");;
        }finally{
           ConnectionFactory.fechaConexao(con, (com.mysql.jdbc.PreparedStatement) stmt, rs);
        }
        return clientes;
        }
       
       public List<ClientesE> readForNome(String nome) {
        Connection con = new ConnectionFactory().conecta();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<ClientesE> clientes = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM ClienteE WHERE NomeE LIKE ?");
            stmt.setString(1, "%"+nome+"%");
            
            rs = stmt.executeQuery();
            
            while (rs.next()){
                ClientesE cliente = new ClientesE();
                cliente.setId(rs.getInt("idClienteE"));
                cliente.setNome(rs.getString("NomeE"));
                cliente.setEmail(rs.getString("EmailE"));
                cliente.setTelefone(rs.getString("Telefone"));
                cliente.setCarro1(rs.getString("Carro1"));
                cliente.setCarro2(rs.getString("Carro2"));
                cliente.setCarro3(rs.getString("Carro3"));
                cliente.setCarro4(rs.getString("Carro4"));
                cliente.setCarro5(rs.getString("Carro5"));
                cliente.setCarro6(rs.getString("Carro6"));
                cliente.setPagto(rs.getString("Pagto"));
                clientes.add(cliente);
                
            }
            
        } catch (SQLException ex) {
            System.out.println("Lista não concluída");;
        }finally{
           ConnectionFactory.fechaConexao(con, (com.mysql.jdbc.PreparedStatement) stmt, rs);
        }
        return clientes;
        }
    } 
