package dao;
import factory.ConnectionFactory;
import modelos.Clientes;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class ClienteDAO { 
    Long id;
    String nome;
    String email;
    String telefone;
    String carro;
    String carro2;
    String carro3; 
    public void adiciona(Clientes cliente){
      
        Connection connection = new ConnectionFactory().conecta();
        try { 
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO Cliente (NomeC,EmailC,TelefoneC,Carro1,Carro2,Carro3,Pagto) VALUES('"
                    + cliente.getNome() + "','" + cliente.getEmail() + "','" + cliente.getTelefone() + "','"
                    + cliente.getCarro1() + "','" + cliente.getCarro2() + "','" + cliente.getCarro3() + "','" + cliente.getPagto() + "');");
            stmt.executeUpdate();
            stmt.close();
        } 
        catch (SQLException ex) { 
            System.err.println("Erro INSERT:" + ex);
        }
    }
    
       public List<Clientes> read() {
        Connection con = new ConnectionFactory().conecta();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Clientes> clientes = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM Cliente");
            rs = stmt.executeQuery();
            
            while (rs.next()){
                Clientes cliente = new Clientes();
                cliente.setId(rs.getInt("idCliente"));
                cliente.setNome(rs.getString("NomeC"));
                cliente.setEmail(rs.getString("EmailC"));
                cliente.setTelefone(rs.getString("TelefoneC"));
                cliente.setCarro1(rs.getString("Carro1"));
                cliente.setCarro2(rs.getString("Carro2"));
                cliente.setCarro3(rs.getString("Carro3"));
                cliente.setPagto(rs.getString("Pagto"));
                clientes.add(cliente);
                
            }
            
        } catch (SQLException ex) {
            System.out.println("Lista não concluída");;
        }finally{
           ConnectionFactory.fechaConexao(con, (com.mysql.jdbc.PreparedStatement) stmt, rs);
        }
        return clientes;
        }
       
       public List<Clientes> readForNome(String nome) {
        Connection con = new ConnectionFactory().conecta();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Clientes> clientes = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM Cliente WHERE NomeC LIKE ?");
            stmt.setString(1, "%"+nome+"%");
            
            rs = stmt.executeQuery();
            
            while (rs.next()){
                Clientes cliente = new Clientes();
                cliente.setId(rs.getInt("idCliente"));
                cliente.setNome(rs.getString("NomeC"));
                cliente.setEmail(rs.getString("EmailC"));
                cliente.setTelefone(rs.getString("TelefoneC"));
                cliente.setCarro1(rs.getString("Carro1"));
                cliente.setCarro2(rs.getString("Carro2"));
                cliente.setCarro3(rs.getString("Carro3"));
                cliente.setCarro3(rs.getString("Pagto"));
                clientes.add(cliente);
                
            }
            
        } catch (SQLException ex) {
            System.out.println("Lista não concluída");;
        }finally{
           ConnectionFactory.fechaConexao(con, (com.mysql.jdbc.PreparedStatement) stmt, rs);
        }
        return clientes;
        }
    } 

